#include<iostream>
#include<cmath>

using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
    double a,b;
    cin>>a>>b;
    double d=log(a/b);
    if(a<=b)
    {
        printf("0.000000\n");
    }
    else
    {
        printf("%.6lf\n",d+1);
    }

    }

}