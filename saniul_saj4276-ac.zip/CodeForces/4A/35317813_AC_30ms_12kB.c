#include<stdio.h>

int main()
{

    int N;
    scanf("%d", &N);
    if(N <= 2 || N%2 != 0)
    {
        printf("NO\n");
    }
    else
    {
        printf("YES\n");
    }

    return 0;
}