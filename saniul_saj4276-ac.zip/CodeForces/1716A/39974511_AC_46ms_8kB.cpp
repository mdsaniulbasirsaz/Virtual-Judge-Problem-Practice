#include<bits/stdc++.h>
using namespace std;
int main()
{
long long t;
cin>>t;
while(t--)
{
long long k;
cin>>k;
long long a,b,c;
a=k%3;
b=k/3;
if(a==0)cout<<b<<endl;
else
{
if(a==1)
{
if(b==0)cout<<"2"<<endl;
else cout<<b+1<<endl;}
else
{if(a==2)cout<<b+1<<endl;}
}
}
}