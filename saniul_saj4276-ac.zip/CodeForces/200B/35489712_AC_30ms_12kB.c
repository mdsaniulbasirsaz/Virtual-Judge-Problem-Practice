#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int p,sum=0;

    for(int i=0;i<n;i++)
    {
        scanf("%d",&p);
        sum=sum+p;
    }
    float s=(float)sum/n;
    printf("%.12f\n",s);
    return 0;
}
