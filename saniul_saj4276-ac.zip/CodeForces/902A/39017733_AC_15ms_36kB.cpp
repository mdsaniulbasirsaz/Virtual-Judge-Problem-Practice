/* Md Saniul Basir Saz 
   Department Of Computer Science and Engineering 
   Jashore University Of Scinece and Technology 
   Student Id: 200103 
   Email: saniul.cse.just@gmail.com
   Mobile: 01306032236 */
#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<queue>
#include<bits/stdc++.h>
#include<string>
#define The_End return 0
#define nl '\n'
#define YSSS cout<<"YES"<<nl
#define NOOO cout<<"NO"<<nl
#define ysss cout<<"Yes"<<<nl
#define nooo cout<<"No"<<nl
#define ll long long 
#define fli(i,a,n) for(int i=a;i<n;i++)
#define flj(j,a,n) for(int j=a;j<n;j++)
#define flri(i,a,n) for(int i=n;i>=a;i--)
#define flrj(j,a,n) for(int j=n;j>=a;j--)
#define mod 1000000007
#define st(n) fixed<<setprecision(n)
#define my_code ios_base::sync_with_stdio(0);cout.tie(0);
using namespace std;
const int MOD = 1000000007;
const int MAX = 1000005;

int main (void)
{
    

    int n,m,i,j,a,b;

    while (scanf ("%d %d",&n,&m) != EOF)
    {
        map <pair<int,int>,bool> mp;

        for (i=0; i<n; i++)
        {
            cin>>a>>b;

            for (j=a+1; j<=b; j++)
                mp[make_pair(j,j-1)] = true;
        }

        if (mp.size() < m)
        cout<<"NO"<<nl;
        else
        cout<<"YES";
    }

    return 0;
}
