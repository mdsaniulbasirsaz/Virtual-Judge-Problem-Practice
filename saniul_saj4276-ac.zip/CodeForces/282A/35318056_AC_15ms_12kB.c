#include<stdio.h>
#include<string.h>
int main(){
  int j,t,s=0;
  char x[4];
  scanf("%d",&t);
  for(j=1;j<=t;j++){
    scanf("%s",&x);
    if((strcmp(x,"X++")==0)||(strcmp(x,"++X")==0)){
        s=s+1;
    }
    else if((strcmp(x,"X--")==0)||(strcmp(x,"--X")==0)){
        s=s-1;
    }
    s=s;
  }

printf("%d\n",s);

return 0;
}