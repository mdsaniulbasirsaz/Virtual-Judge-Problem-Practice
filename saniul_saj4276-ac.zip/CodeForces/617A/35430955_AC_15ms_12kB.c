#include<stdio.h>
int main()
{
    int n,s;
    scanf("%d",&n);
    s=n/5;
    if(n%5==0)
    {
        printf("%d\n",s);
    }
    else
    {
        printf("%d\n",s+1);
    }
    return 0;
}