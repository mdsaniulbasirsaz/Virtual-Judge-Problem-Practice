#include<stdio.h>
int main()
{
   int N,M,s=0;
   scanf("%d%d",&N,&M);
   s=(N*M)/2;
   printf("%d\n",s);
    return 0;
}
