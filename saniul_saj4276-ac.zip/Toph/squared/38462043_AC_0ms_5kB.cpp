#include<iostream>
using namespace std;
int main()
{
int t;
cin>>t;
cout<<t*t<<endl;
}