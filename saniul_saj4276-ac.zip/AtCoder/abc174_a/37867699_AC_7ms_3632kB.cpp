#include<iostream>
using namespace std;
int main()
{
	
	int n;
	cin>>n;
	if(n>=30)
	{
		cout<<"Yes"<<endl;
	}
	else
		cout<<"No"<<endl;
	return 0;
}