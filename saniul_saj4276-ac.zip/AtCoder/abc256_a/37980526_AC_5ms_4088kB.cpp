#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	long long p,c;
	cin>>p;
	c=pow(2,p);
	cout<<c<<endl;

	return 0;
}