#include<stdio.h>
int main()
{
    int H,W;
    scanf("%d%d",&H,&W);
    long arr[H][W];
    for(int i=0; i<H; i++)
    {
        for(int j=0; j<W; j++)
        {
            scanf("%ld",&arr[i][j]);
        }
    }
    for(int i=0;i<W;i++)
    {
        for(int j=0;j<H;j++)
        {
            printf("%ld ",arr[j][i]);
        }
        printf("\n");
    }
    return 0;
}