#include<iostream>
#include<algorithm>
#include<vector>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b;
	cin>>a>>b;
	int x=1;
	if(a>b){
	for(int i=1;i<=a-b;i++)
	{
		x*=32;
	}
	cout<<x<<endl;
}
	else
	{
		cout<<"1"<<endl;
	}

	return 0;
}