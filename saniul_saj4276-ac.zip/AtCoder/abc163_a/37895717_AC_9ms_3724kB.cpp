#include<iostream>
using namespace std;
int main()
{
	int r;
	cin>>r;
	float R=2*3.1416*(float)r;
	printf("%.20lf\n",R);
	return 0;
}