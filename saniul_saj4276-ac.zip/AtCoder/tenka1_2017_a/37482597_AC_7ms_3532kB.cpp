#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main() 
{
    int count=0;
    char str[6];
    cin>>str;
    for(int i=0; i<6; i++)
    {
        if(str[i]=='1')
        {
            count++;
        }
    }
    cout<<count<<endl;

}