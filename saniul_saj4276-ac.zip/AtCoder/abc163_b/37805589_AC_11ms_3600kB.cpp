#include<iostream>
using namespace std;
int main()
{
    int n,m,su=0;
    cin>>n>>m;
    int arr[m];
    for(int i=0;i<m;i++)
    {
        cin>>arr[i];
        su+=arr[i];
    }
    if(n<su)
    {
        cout<<"-1"<<endl;
    }
    else
    {
        cout<<n-su<<endl;
    }
    return 0;
}