#include<stdio.h>
int main()
{
    float D;
    scanf("%f",&D);
    printf("%f\n",D/100);
    return 0;
}
