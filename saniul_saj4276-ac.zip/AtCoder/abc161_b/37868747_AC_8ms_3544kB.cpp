#include<iostream>
#include<vector>
#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main()
{
	int n,a;
	cin>>n>>a;
	int s[n];
	int sum=0;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
		sum+=s[i];
	}
	
	int count=0;
	for(int i=1;i<=n;i++)
	{
		if(s[i]*4*a>=sum)
		{
			count++;
		}

	}
	if(count>=a)
	{
		cout<<"Yes"<<endl;
	}
	else
	{
		cout<<"No"<<endl;
	}

	
	return 0;
}