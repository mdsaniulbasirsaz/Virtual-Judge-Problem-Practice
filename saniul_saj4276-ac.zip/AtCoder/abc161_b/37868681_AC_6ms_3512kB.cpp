#include<iostream>
#include<vector>
#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	int s[n];
	int sum=0;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
		sum+=s[i];
	}
	
	int count=0;
	for(int i=1;i<=n;i++)
	{
		if(s[i]*4*m>=sum)
		{
			count++;
		}

	}
	if(count>=m)
	{
		cout<<"Yes"<<endl;
	}
	else
	{
		cout<<"No"<<endl;
	}

	
	return 0;
}