#include<iostream>
#include<cmath>
#include<algorithm>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	long long arr[n];
	long long  c=0,d=0;
	int e=0;
	for(int i=0;i<n;i++)
	{
		cin>>arr[i];
		arr[i]=abs(arr[i]);
		c+=arr[i];
		d+=arr[i]*arr[i];
		if(arr[i]>e)
		{
			e=arr[i];
		}
	}
	cout<<c<<endl;
	cout<<fixed<<setprecision(15)<<sqrt(d)<<endl;
	cout<<e<<endl;
	return 0;
}