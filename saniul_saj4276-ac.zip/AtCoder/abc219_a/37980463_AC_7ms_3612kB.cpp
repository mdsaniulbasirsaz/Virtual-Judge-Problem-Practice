#include<iostream>
using namespace std;
int main()
{
	int p;
	cin>>p;
	if(p>=90)
	{
		cout<<"expert"<<endl;
	}
	else if(p<40)
	{
		cout<<40-p<<endl;
	}
	else if(40<=p&&p<70)
	{
		cout<<70-p<<endl;
	}
	else if(70<=p&&p<90)
		cout<<90-p<<endl;

	return 0;
}