#include<iostream>
using namespace std;
int main()
{
	long long a,b;
	cin>>a>>b;
	if((a*500)>=b)
		cout<<"Yes"<<endl;
	else
		cout<<"No"<<endl;
	return 0;
}