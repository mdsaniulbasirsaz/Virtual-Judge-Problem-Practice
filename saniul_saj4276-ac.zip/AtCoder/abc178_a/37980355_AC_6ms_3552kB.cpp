#include<iostream>
using namespace std;
int main()
{
	int p;
	cin>>p;
	if(p==1)
	{
		cout<<"0"<<endl;
	}
	else
		cout<<"1"<<endl;

	return 0;
}