#include<stdio.h>
int main()
{
    int n,x;
    scanf("%d",&n);
    printf("W");
    for(x=1;x<=n;x++)
    {
        printf("o",x);
    }
    printf("w");
    return 0;
}
