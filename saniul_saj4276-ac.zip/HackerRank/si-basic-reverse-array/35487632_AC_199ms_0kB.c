#include<stdio.h>
int main()
{
    int N;
    scanf("%d",&N);
    long long arr[N];
    for(int i=0;i<N;i++)
    {
        scanf("%llu",&arr[i]);
    }
    for(int i=N-1;i>-1;i--)
    {
       printf("%llu ",arr[i]);
    }

    return 0;
}