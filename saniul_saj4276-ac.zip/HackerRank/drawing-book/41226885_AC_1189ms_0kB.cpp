#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,p;cin>>n>>p;
    int a,b;
    if(p%2==0)
    {
        a=p/2;
    }
    else
    {
        a=(p-1)/2;
    }
    
    if(n%2==0)
    {
        b=(n+1-p)/2;
    }
    else{
        b=(n-p)/2;
    }
    cout<<min(a,b)<<endl;
    return 0;
}