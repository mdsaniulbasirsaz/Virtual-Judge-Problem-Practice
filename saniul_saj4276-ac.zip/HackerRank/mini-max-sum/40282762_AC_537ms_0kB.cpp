#include <iostream>
#include <algorithm>
using namespace std;

void miniMaxSum(int arr[], int n) {
  // sort the array
  std::sort(arr, arr + n);

  // calculate the minimum sum by adding the first four elements
  long long minSum = 0;
  for (int i = 0; i < n - 1; i++) {
    minSum += arr[i];
  }

  // calculate the maximum sum by adding the last four elements
  long long maxSum = 0;
  for (int i = 1; i < n; i++) {
    maxSum += arr[i];
  }

  // print the results
  std::cout << minSum << " " << maxSum << std::endl;
}

int main() {
  int n=5;
  int arr[5];
  for(int i=0;i<5;i++)
  {
      cin>>arr[i];
  }
  miniMaxSum(arr, n);  // prints 10 14

  return 0;
}
