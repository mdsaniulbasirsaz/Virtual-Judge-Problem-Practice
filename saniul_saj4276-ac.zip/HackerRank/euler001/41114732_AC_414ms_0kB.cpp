/* Md Saniul Basir Saz 
   Department Of Computer Science and Engineering 
   Jashore University Of Scinece and Technology 
   Student Id: 200103 
   Email: saniul.cse.just@gmail.com
   Mobile: 01306032236 */
#include<iostream>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<queue>
#include<bits/stdc++.h>
#include<string>
#define The_End return 0
#define nl '\n'
#define YSSS cout<<"YES"<<nl
#define NOOO cout<<"NO"<<nl
#define ysss cout<<"Yes"<<<nl
#define nooo cout<<"No"<<nl
#define ll long long 
#define fli(i,a,n) for(int i=a;i<n;i++)
#define flj(j,a,n) for(int j=a;j<n;j++)
#define flri(i,a,n) for(int i=n;i>=a;i--)
#define flrj(j,a,n) for(int j=n;j>=a;j--)
#define mod 1000000007
#define st(n) fixed<<setprecision(n)
#define my_code ios_base::sync_with_stdio(0);cout.tie(0);
using namespace std;
int main()
{
  my_code
  int t;
  cin>>t;
  while(t--)
  
  {
      ll n;cin>>n;
      long a = 0, b = 0, d = 0;

            // Here a, b and d are the count of numbers divisible by 3, 5 and 15 respectively
            a = (n - 1) / 3;
            b = (n - 1) / 5;
            d = (n - 1) / 15;

            // To get the sum of all numbers divisible by 3 (sum3) i.e. 3+6+9+-----+3n = 3(1+2+3+---+n) = 3*n(n+1)/2
            // Similarly sum of all numbers divisible by 5 (sum5) is 5*n(n+1)/2
            // Sum of numbers divisible by 15 (sum15) is 15*n(n+1)/2.
            long sum3 = 3 * a * (a + 1) / 2;
            long sum5 = 5 * b * (b + 1) / 2;
            long sum15 = 15 * d * (d + 1) / 2;
            long c = sum3 + sum5 - sum15;
            cout<<c<<nl;
  }
  The_End;
}
