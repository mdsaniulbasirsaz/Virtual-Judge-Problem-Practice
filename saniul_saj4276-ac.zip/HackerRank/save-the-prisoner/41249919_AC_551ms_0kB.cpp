#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;cin>>t;
    while(t--)
    {
    int n,m,s;
    cin>>n>>m>>s;
    int r=m%n;
    int ans=s-1+r;
    if(ans%n==0)
    {
        cout<<n<<endl;
    }
    else {
    cout<<ans%n<<endl;
    }
    }
    return 0;
}
