#include <iostream>
#include <cmath>

int main() {
  int t;
  std::cin >> t;

  while (t--) {
    long long n;
    std::cin >> n;
    long long root = std::sqrt(2 * n);
    if (root * (root + 1) == 2 * n) {
      std::cout << root << std::endl;
    } else {
      std::cout << -1 << std::endl;
    }
  }
  return 0;
}
