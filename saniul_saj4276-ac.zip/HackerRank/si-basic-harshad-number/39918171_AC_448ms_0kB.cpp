#include<iostream>
using namespace std;
int main()
{

    int n;
    cin>>n;
    int s=0,b=n;
    while(b!=0)
    {
        s+=b%10;
        b/=10;
    }
    if(n%s==0)
    {
        cout<<"Yes"<<endl;
    }
    else cout<<"No"<<endl;
    return 0;
}
