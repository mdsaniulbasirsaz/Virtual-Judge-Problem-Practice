#include<bits/stdc++.h>
#include<math.h>
using namespace std;
int main()
{
    int t;cin>>t;
    while(t--)
    {
    int a,b,c;cin>>a>>b>>c;
    if(a==b &&b==c || abs(a-c)==abs(b-c))
    {
        cout<<"Mouse C"<<endl;
    }
    else if(abs(a-c)<abs(b-c))
    {
        cout<<"Cat A"<<endl;
    }
    else {
    cout<<"Cat B"<<endl;
    }

    }
    return 0;
}