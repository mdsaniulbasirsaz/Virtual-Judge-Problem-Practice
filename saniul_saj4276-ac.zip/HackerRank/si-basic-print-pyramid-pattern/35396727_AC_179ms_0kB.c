#include<stdio.h>
main()
{
    int len,i,j;
    int fp,lp;
    scanf("%d",&len);

    fp = lp = len-1;

    for(i=0; i<len; i++)
    {
        for(j=0; j<2*len-1; j++)
        {
            if(j>=fp && j<=lp)
                printf("*",j);
            else
                printf(" ");
        }
        fp--,lp++;

        printf("\n");
    }
    return 0;
}
