#include<iostream>
#include<bits/stdc++.h>
#include<math.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    vector<int>v(n);
    int x;
    for(int i=0;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
    }
    
    sort(v.begin(),v.end());
    reverse(v.begin(),v.end());
    long long sum=0;
    for(int i=0;i<v.size();i++)
    {
        sum+=(pow(2,i))*v[i];
    }
cout<<sum<<endl;
}
