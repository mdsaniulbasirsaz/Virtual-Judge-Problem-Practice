#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;cin>>n;
    int k;cin>>k;
    vector<int>v;
    for(int i=0,x;i<n;i++)
    {
        cin>>x;
        v.push_back(x);
    }
    int count=0;
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if((v[i]+v[j])%k==0)
            {
                count++;
            }
        }
    }
    cout<<count<<endl;
    return 0;
}
