#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		long long n;
		cin>>n;
		if((n&(n-1))!=0)
			cout<<"False\n";
		else
			cout<<"True\n";

	}
	return 0;
}